# -*- coding:utf-8 -*-
__author__ = 'Ulric Qin'

from web import app

if __name__ == '__main__':
    app.run(port=5050, debug=True)
